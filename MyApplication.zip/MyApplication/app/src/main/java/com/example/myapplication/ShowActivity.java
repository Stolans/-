package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ShowActivity extends AppCompatActivity{
    private TextView tvSecName, tvName, tvOtch, tvStaj;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_layout);
        init();
        getIntentMain();
    }
    private void init()
    {
        tvSecName = findViewById(R.id.tvSecName);
        tvName = findViewById(R.id.tvName);
        tvOtch = findViewById(R.id.tvOtch);
        tvStaj = findViewById(R.id.tvStaj);
    }
    private void getIntentMain()
    {
        Intent i = getIntent();
        if(i !=null)
        {
            tvSecName.setText(i.getStringExtra("user_sec_name"));
            tvName.setText(i.getStringExtra("user_name"));
            tvOtch.setText(i.getStringExtra("user_otch"));
            tvStaj.setText(i.getStringExtra("user_staj"));
        }
    }
}
