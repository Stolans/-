package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickClose(View view) {
        System.exit(0);
    }

    public void onClickRead(View view) {
        Intent i = new Intent(MainActivity.this, ReadActivity.class);
        startActivity(i);
    }

    public void onClickSave(View view) {
        Intent i = new Intent(MainActivity.this, ShowActivity.class);
        startActivity(i);
    }
}